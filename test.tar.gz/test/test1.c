#ifdef CTRL
# include <stdlib.h>
#else
# include "malloc.h"
#endif

int		main()
{
    int     i;
    char    *addr;

    i = 0;
    while (i < 1024)
    {
        addr = (char *)malloc(1024);
        addr[0] = 42;
        i++;
    }
	return (0);
}
